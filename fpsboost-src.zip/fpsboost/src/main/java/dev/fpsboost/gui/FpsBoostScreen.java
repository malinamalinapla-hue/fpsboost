package dev.fpsboost.gui;

import dev.fpsboost.FpsBoostConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.IntConsumer;

public class FpsBoostScreen extends Screen {
    private static final String[] TABS = {"Графика", "Дальность", "Прочее"};
    private static final String[] PARTICLES = {"Все", "Меньше", "Минимум"};
    private static int lastPage = 0;

    private final Screen parent;
    private final FpsBoostConfig cfg = FpsBoostConfig.get();
    private int page = lastPage;

    public FpsBoostScreen(Screen parent) {
        super(Text.literal("FPS Boost"));
        this.parent = parent;
    }

    private void rebuild() {
        this.clearChildren();
        this.init();
    }

    private static int row(int r) {
        return 56 + r * 24;
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int colW = 150;
        int left = cx - colW - 3;
        int right = cx + 3;

        // Вкладки
        for (int i = 0; i < TABS.length; i++) {
            final int idx = i;
            ButtonWidget tab = ButtonWidget.builder(Text.literal(TABS[i]), b -> {
                page = idx;
                lastPage = idx;
                this.client.send(this::rebuild);
            }).dimensions(cx - 148 + i * 100, 28, 96, 20).build();
            tab.active = i != page;
            addDrawableChild(tab);
        }

        if (page == 0) {
            addDrawableChild(toggle(left, row(0), colW, "Убрать облака", () -> cfg.noClouds, v -> cfg.noClouds = v, false));
            addDrawableChild(toggle(left, row(1), colW, "Убрать траву", () -> cfg.noGrass, v -> cfg.noGrass = v, true));
            addDrawableChild(toggle(left, row(2), colW, "Убрать цветы", () -> cfg.noFlowers, v -> cfg.noFlowers = v, true));
            addDrawableChild(toggle(left, row(3), colW, "Быстрая графика", () -> cfg.fastGraphics, v -> cfg.fastGraphics = v, false));
            addDrawableChild(toggle(left, row(4), colW, "Без теней сущностей", () -> cfg.noShadows, v -> cfg.noShadows = v, false));

            addDrawableChild(toggle(right, row(0), colW, "Без плавного света", () -> cfg.noSmoothLighting, v -> cfg.noSmoothLighting = v, false));
            addDrawableChild(particlesButton(right, row(1), colW));
            addDrawableChild(new IntSlider(right, row(2), colW, "Смешивание биомов", 0, 7, cfg.biomeBlend,
                    v -> cfg.biomeBlend = v, cfg::applyOptions));
            addDrawableChild(toggle(right, row(3), colW, "Без верт. синхронизации", () -> cfg.vsyncOff, v -> cfg.vsyncOff = v, false));
            addDrawableChild(toggle(right, row(4), colW, "Без лимита FPS", () -> cfg.unlimitedFps, v -> cfg.unlimitedFps = v, false));
        } else if (page == 1) {
            addDrawableChild(new IntSlider(left, row(0), colW, "Прорисовка", 2, 32, cfg.renderDistance,
                    v -> cfg.renderDistance = v, cfg::applyOptions));
            addDrawableChild(new IntSlider(left, row(1), colW, "Симуляция", 5, 32, cfg.simulationDistance,
                    v -> cfg.simulationDistance = v, cfg::applyOptions));

            addDrawableChild(toggle(right, row(0), colW, "Лимит игроков", () -> cfg.limitPlayers, v -> cfg.limitPlayers = v, false));
            addDrawableChild(new IntSlider(right, row(1), colW, "Игроки до (блоков)", 4, 128, cfg.playerDistance,
                    v -> cfg.playerDistance = v, () -> {}));
            addDrawableChild(toggle(right, row(2), colW, "Лимит сущностей", () -> cfg.limitEntities, v -> cfg.limitEntities = v, false));
            addDrawableChild(new IntSlider(right, row(3), colW, "Сущности до (блоков)", 8, 128, cfg.entityDistance,
                    v -> cfg.entityDistance = v, () -> {}));
        } else {
            addDrawableChild(toggle(left, row(0), colW, "Мод включён", () -> cfg.enabled, v -> cfg.enabled = v, true));
            addDrawableChild(toggle(left, row(1), colW, "Показывать FPS", () -> cfg.showFps, v -> cfg.showFps = v, false));

            addDrawableChild(button(right, row(0), colW, "Пресет: макс. FPS", () -> { cfg.presetMax(); afterPreset(); }));
            addDrawableChild(button(right, row(1), colW, "Пресет: баланс", () -> { cfg.presetBalanced(); afterPreset(); }));
            addDrawableChild(button(right, row(2), colW, "Сбросить настройки", () -> { cfg.resetDefaults(); afterPreset(); }));
        }

        addDrawableChild(ButtonWidget.builder(Text.literal("Готово"), b -> close())
                .dimensions(cx - 75, this.height - 26, 150, 20).build());
    }

    private void afterPreset() {
        cfg.applyOptions();
        reloadWorld();
        this.client.send(this::rebuild);
    }

    private void reloadWorld() {
        if (this.client != null && this.client.world != null) {
            this.client.worldRenderer.reload();
        }
    }

    private ButtonWidget button(int x, int y, int w, String label, Runnable action) {
        return ButtonWidget.builder(Text.literal(label), b -> action.run())
                .dimensions(x, y, w, 20).build();
    }

    private Text toggleText(String name, boolean on) {
        return Text.literal(name + ": ")
                .append(Text.literal(on ? "ВКЛ" : "ВЫКЛ").formatted(on ? Formatting.GREEN : Formatting.RED));
    }

    private ButtonWidget toggle(int x, int y, int w, String name, BooleanSupplier get,
                                Consumer<Boolean> set, boolean reloadChunks) {
        return ButtonWidget.builder(toggleText(name, get.getAsBoolean()), b -> {
            boolean v = !get.getAsBoolean();
            set.accept(v);
            b.setMessage(toggleText(name, v));
            cfg.applyOptions();
            if (reloadChunks) reloadWorld();
        }).dimensions(x, y, w, 20).build();
    }

    private ButtonWidget particlesButton(int x, int y, int w) {
        return ButtonWidget.builder(Text.literal("Частицы: " + PARTICLES[cfg.particles]), b -> {
            cfg.particles = (cfg.particles + 1) % PARTICLES.length;
            b.setMessage(Text.literal("Частицы: " + PARTICLES[cfg.particles]));
            cfg.applyOptions();
        }).dimensions(x, y, w, 20).build();
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 10, 0xFFFFFF);
        if (this.height >= 230) {
            context.drawCenteredTextWithShadow(this.textRenderer,
                    Text.literal("Открыть меню: /fpsboost или кнопка в меню паузы"),
                    this.width / 2, this.height - 42, 0xAAAAAA);
        }
    }

    @Override
    public void close() {
        cfg.sanitize();
        cfg.applyOptions();
        cfg.save();
        if (this.client != null) {
            this.client.options.write();
            this.client.setScreen(parent);
        }
    }

    /** Слайдер с целыми значениями. */
    private static class IntSlider extends SliderWidget {
        private final String name;
        private final int min;
        private final int max;
        private final IntConsumer onValue;
        private final Runnable onCommit;

        IntSlider(int x, int y, int w, String name, int min, int max, int initial,
                  IntConsumer onValue, Runnable onCommit) {
            super(x, y, w, 20, Text.empty(), (double) (initial - min) / (max - min));
            this.name = name;
            this.min = min;
            this.max = max;
            this.onValue = onValue;
            this.onCommit = onCommit;
            this.updateMessage();
        }

        private int current() {
            return min + (int) Math.round(this.value * (max - min));
        }

        @Override
        protected void updateMessage() {
            this.setMessage(Text.literal(name + ": " + current()));
        }

        @Override
        protected void applyValue() {
            onValue.accept(current());
        }

        @Override
        public void onRelease(double mouseX, double mouseY) {
            super.onRelease(mouseX, mouseY);
            onCommit.run();
        }
    }
}

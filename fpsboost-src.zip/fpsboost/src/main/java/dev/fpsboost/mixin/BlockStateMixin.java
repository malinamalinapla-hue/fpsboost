package dev.fpsboost.mixin;

import dev.fpsboost.FpsBoostConfig;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockRenderType;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.TagKey;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Делает траву и цветы невидимыми для рендера (коллизия и логика не меняются).
 */
@Mixin(AbstractBlock.AbstractBlockState.class)
public abstract class BlockStateMixin {

    @Shadow
    public abstract Block getBlock();

    @Shadow
    public abstract boolean isIn(TagKey<Block> tag);

    @Inject(method = "getRenderType", at = @At("HEAD"), cancellable = true)
    private void fpsboost$hidePlants(CallbackInfoReturnable<BlockRenderType> cir) {
        FpsBoostConfig c = FpsBoostConfig.get();
        if (!c.enabled || (!c.noGrass && !c.noFlowers)) return;

        if (c.noGrass && FpsBoostConfig.isGrass(this.getBlock())) {
            cir.setReturnValue(BlockRenderType.INVISIBLE);
        } else if (c.noFlowers && this.isIn(BlockTags.FLOWERS)) {
            cir.setReturnValue(BlockRenderType.INVISIBLE);
        }
    }
}

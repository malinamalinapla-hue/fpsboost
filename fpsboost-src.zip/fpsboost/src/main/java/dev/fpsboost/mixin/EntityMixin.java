package dev.fpsboost.mixin;

import dev.fpsboost.FpsBoostConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Не рисует игроков и другие сущности дальше заданной дистанции.
 * Параметр distance здесь — квадрат расстояния до камеры.
 */
@Mixin(Entity.class)
public abstract class EntityMixin {

    @Inject(method = "shouldRender(D)Z", at = @At("HEAD"), cancellable = true)
    private void fpsboost$distanceCull(double distance, CallbackInfoReturnable<Boolean> cir) {
        FpsBoostConfig c = FpsBoostConfig.get();
        if (!c.enabled) return;

        Entity self = (Entity) (Object) this;
        if (self instanceof PlayerEntity) {
            if (c.limitPlayers && self != MinecraftClient.getInstance().player) {
                double max = c.playerDistance;
                if (distance > max * max) cir.setReturnValue(false);
            }
        } else if (c.limitEntities) {
            double max = c.entityDistance;
            if (distance > max * max) cir.setReturnValue(false);
        }
    }
}

package dev.fpsboost;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.option.SimpleOption;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

public class FpsBoostConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static FpsBoostConfig instance = new FpsBoostConfig();

    // Общий выключатель
    public boolean enabled;

    // Мир
    public boolean noGrass;
    public boolean noFlowers;
    public boolean noClouds;

    // Графика
    public boolean fastGraphics;
    public boolean noShadows;
    public boolean noSmoothLighting;
    public int particles;      // 0 все, 1 меньше, 2 минимум
    public int biomeBlend;     // 0..7
    public boolean vsyncOff;
    public boolean unlimitedFps;

    // Дальность
    public int renderDistance;
    public int simulationDistance;
    public boolean limitPlayers;
    public int playerDistance;
    public boolean limitEntities;
    public int entityDistance;

    // Прочее
    public boolean showFps;

    public FpsBoostConfig() {
        resetDefaults();
    }

    public static FpsBoostConfig get() {
        return instance;
    }

    public void resetDefaults() {
        enabled = true;
        noGrass = true;
        noFlowers = false;
        noClouds = true;
        fastGraphics = true;
        noShadows = true;
        noSmoothLighting = true;
        particles = 2;
        biomeBlend = 0;
        vsyncOff = true;
        unlimitedFps = true;
        renderDistance = 8;
        simulationDistance = 5;
        limitPlayers = true;
        playerDistance = 24;
        limitEntities = true;
        entityDistance = 48;
        showFps = true;
    }

    public void presetMax() {
        resetDefaults();
        noFlowers = true;
        renderDistance = 6;
        simulationDistance = 5;
        playerDistance = 16;
        entityDistance = 32;
    }

    public void presetBalanced() {
        resetDefaults();
        particles = 1;
        biomeBlend = 1;
        renderDistance = 10;
        simulationDistance = 6;
        playerDistance = 40;
        entityDistance = 64;
    }

    public static boolean isGrass(Block b) {
        return b == Blocks.SHORT_GRASS || b == Blocks.TALL_GRASS
                || b == Blocks.FERN || b == Blocks.LARGE_FERN
                || b == Blocks.DEAD_BUSH
                || b == Blocks.SEAGRASS || b == Blocks.TALL_SEAGRASS;
    }

    private static int clamp(int v, int min, int max) {
        return Math.max(min, Math.min(max, v));
    }

    public void sanitize() {
        playerDistance = clamp(playerDistance, 4, 128);
        entityDistance = clamp(entityDistance, 8, 128);
        renderDistance = clamp(renderDistance, 2, 32);
        simulationDistance = clamp(simulationDistance, 5, 32);
        biomeBlend = clamp(biomeBlend, 0, 7);
        particles = clamp(particles, 0, 2);
    }

    /** Применяет настройки видео к ванильным опциям игры. */
    public void applyOptions() {
        if (!enabled) return;
        try {
            MinecraftClient mc = MinecraftClient.getInstance();
            GameOptions o = mc == null ? null : mc.options;
            if (o == null) return;
            sanitize();

            o.getCloudRenderMode().setValue(noClouds ? CloudRenderMode.OFF : CloudRenderMode.FAST);
            o.getGraphicsMode().setValue(fastGraphics ? GraphicsMode.FAST : GraphicsMode.FANCY);
            o.getAo().setValue(!noSmoothLighting);
            o.getEntityShadows().setValue(!noShadows);
            setParticles(o, particles);
            o.getBiomeBlendRadius().setValue(biomeBlend);
            o.getEnableVsync().setValue(!vsyncOff);
            o.getMaxFps().setValue(unlimitedFps ? 260 : 120);
            o.getViewDistance().setValue(renderDistance);
            o.getSimulationDistance().setValue(simulationDistance);
        } catch (Throwable t) {
            FpsBoostClient.LOGGER.warn("Не удалось применить настройки видео", t);
        }
    }

    /** Частицы: 0 все, 1 меньше, 2 минимум. Без прямого имени enum, чтобы не зависеть от маппингов. */
    @SuppressWarnings({"unchecked", "rawtypes"})
    private static void setParticles(GameOptions o, int index) {
        SimpleOption option = o.getParticles();
        Object current = option.getValue();
        if (current instanceof Enum<?> e) {
            Object[] values = e.getDeclaringClass().getEnumConstants();
            option.setValue(values[Math.max(0, Math.min(values.length - 1, index))]);
        }
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("fpsboost.json");
    }

    public static void load() {
        Path p = file();
        if (Files.exists(p)) {
            try (Reader r = Files.newBufferedReader(p)) {
                FpsBoostConfig c = GSON.fromJson(r, FpsBoostConfig.class);
                if (c != null) instance = c;
            } catch (Exception e) {
                FpsBoostClient.LOGGER.warn("Не удалось прочитать конфиг, беру настройки по умолчанию", e);
            }
        }
        instance.sanitize();
        instance.save();
    }

    public void save() {
        try (Writer w = Files.newBufferedWriter(file())) {
            GSON.toJson(this, w);
        } catch (Exception e) {
            FpsBoostClient.LOGGER.warn("Не удалось сохранить конфиг", e);
        }
    }
}

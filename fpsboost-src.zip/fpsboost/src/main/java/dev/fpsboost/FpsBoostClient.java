package dev.fpsboost;

import dev.fpsboost.gui.FpsBoostScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FpsBoostClient implements ClientModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("fpsboost");

    private static KeyBinding openKey;
    private static boolean openNextTick = false;

    @Override
    public void onInitializeClient() {
        FpsBoostConfig.load();

        // Клавиша открытия GUI (по умолчанию Right Shift; на телефоне можно назначить на экранную кнопку)
        openKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.fpsboost.open", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.fpsboost"));

        // Применить настройки видео после запуска игры
        ClientLifecycleEvents.CLIENT_STARTED.register(client -> FpsBoostConfig.get().applyOptions());

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openKey.wasPressed()) {
                if (!(client.currentScreen instanceof FpsBoostScreen)) {
                    client.setScreen(new FpsBoostScreen(client.currentScreen));
                }
            }
            if (openNextTick) {
                openNextTick = false;
                client.setScreen(new FpsBoostScreen(null));
            }
        });

        // Команды /fpsboost и /fpsb
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(ClientCommandManager.literal("fpsboost").executes(ctx -> {
                openNextTick = true;
                return 1;
            }));
            dispatcher.register(ClientCommandManager.literal("fpsb").executes(ctx -> {
                openNextTick = true;
                return 1;
            }));
        });

        // Кнопка "FPS Boost" в меню паузы и на главном экране (удобно на телефоне)
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (screen instanceof GameMenuScreen || screen instanceof TitleScreen) {
                Screens.getButtons(screen).add(
                        ButtonWidget.builder(Text.literal("FPS Boost"),
                                        b -> client.setScreen(new FpsBoostScreen(screen)))
                                .dimensions(6, 6, 90, 20).build());
            }
        });

        // Счётчик FPS
        HudRenderCallback.EVENT.register((context, tickCounter) -> {
            FpsBoostConfig c = FpsBoostConfig.get();
            if (!c.showFps) return;
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.options.hudHidden || mc.getDebugHud().shouldShowDebugHud()) return;
            context.drawTextWithShadow(mc.textRenderer, mc.getCurrentFps() + " FPS", 4, 4, 0xFFFFFF);
        });
    }
}
